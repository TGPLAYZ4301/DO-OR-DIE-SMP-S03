sudo apt install npm 
npm install -g pm2
pm2 start ngrokk.sh #In that file, replace the ngrok authtoken with yours
