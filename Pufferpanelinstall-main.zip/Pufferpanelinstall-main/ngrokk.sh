#!/bin/sh
./ngrok http 8080
